package javabasics;

public class patient {
	String name;
	float age;
	int id;
	
	
	void disease(){
		System.out.println("Disease found..");
	}
	
	void prescription(){
		System.out.println("Prescribed..");
	}

}


